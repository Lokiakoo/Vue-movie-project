<template>
  <div style="text-align: center">
    <h1>Page not found</h1>
    <div>The page you are looking for has been removed or doesn't exist</div>
    <q-btn class="q-ma-md" color="primary" @click="$router.push('/')">Go to Homepage</q-btn>
  </div>
</template>  