<template>
    <q-page-scroller position="bottom-right" :scroll-offset="150" :offset="[18, 18]">
      <q-btn fab color="orange" >
        <img src="https://cdn2.iconfinder.com/data/icons/roundid-user-interface/32/arrow_up_direction_chevron.png" style="height:20px; width:20px">
      </q-btn>
    </q-page-scroller>
</template>